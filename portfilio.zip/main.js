var typed= new Typed(".text",{
    strings: ["Frontend Developer","Gamer","Editior"],
    typespeed:100,
    backspeed:100,
    backdelay:1000,
    loop:true
})